#include "Game.h"
#include <iostream>
#include <limits>

Game::Game() : currentPlayerIndex(0), gameOver(false) {
    players.push_back(Player("Jugador 1", 'X'));
    players.push_back(Player("Jugador 2", 'O'));
    board.initializeBoard(players[0], players[1]);
}

void Game::displayMenu() {
    std::cout << "\n=== Menu de Damas ===\n";
    std::cout << "1. Iniciar partida\n";
    std::cout << "2. Ver reglas\n";
    std::cout << "3. Salir\n";
    std::cout << "Selecciona una opcion: ";
}

void Game::startGame() {
    gameOver = false;
    currentPlayerIndex = 0;
    board.initializeBoard(players[0], players[1]);
    std::cout << "Partida iniciada!\n";
    board.display();
    while (!gameOver) {
        handleTurn();
        if (checkVictory()) {
            gameOver = true;
            displayWinner();
        }
    }
}

void Game::showRules() {
    std::cout << "\n=== Reglas del Juego ===\n";
    std::cout << "- Tablero 10x10 con piezas en casillas oscuras.\n";
    std::cout << "- Movimiento: Diagonal a casilla vacia adyacente.\n";
    std::cout << "- Captura: Saltar sobre pieza oponente a casilla vacia detras (obligatoria).\n";
    std::cout << "- Capturas multiples: Encadenadas en un turno.\n";
    std::cout << "- Coronacion: Al llegar a la ultima fila, se convierte en Dama (mueve en cualquier diagonal).\n";
    std::cout << "- Victoria: Capturar todas las piezas o dejar sin movimientos.\n";
    std::cout << "- Ingresa coordenadas como fila,columna (0-9).\n";
}

void Game::handleTurn() {
    Player& currentPlayer = players[currentPlayerIndex];
    std::cout << "\nTurno de " << currentPlayer.getName() << " (" << currentPlayer.getSymbol() << ")\n";

    // Verificar capturas obligatorias
    if (board.hasMandatoryCaptures(currentPlayer)) {
        std::cout << "Tienes capturas obligatorias. Debes capturar.\n";
    }

    int startRow, startCol, endRow, endCol;
    bool validMove = false;
    while (!validMove) {
        std::cout << "Selecciona pieza (fila,columna): ";
        std::cin >> startRow >> startCol;
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Entrada invalida. Intenta de nuevo.\n";
            continue;
        }
        std::cout << "Selecciona destino (fila,columna): ";
        std::cin >> endRow >> endCol;
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Entrada invalida. Intenta de nuevo.\n";
            continue;
        }

        if (board.movePiece(currentPlayer, startRow, startCol, endRow, endCol)) {
            validMove = true;
            board.display();
            // Verificar capturas multiples
            while (board.canCaptureMore(currentPlayer, endRow, endCol)) {
                std::cout << "Captura multiple posible. Continua desde " << endRow << "," << endCol << ".\n";
                std::cout << "Selecciona nuevo destino (fila,columna): ";
                std::cin >> endRow >> endCol;
                if (std::cin.fail()) {
                    std::cin.clear();
                    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                    std::cout << "Entrada invalida. Intenta de nuevo.\n";
                    continue;
                }
                if (!board.continueCapture(currentPlayer, endRow, endCol)) {
                    std::cout << "Movimiento invalido. Pierdes el turno.\n";
                    break;
                }
                board.display();
            }
        } else {
            std::cout << "Movimiento invalido. Intenta de nuevo.\n";
        }
    }

    currentPlayerIndex = (currentPlayerIndex + 1) % 2;
}

bool Game::checkVictory() {
    for (auto& player : players) {
        if (player.getPiecesLeft() == 0 || !board.hasValidMoves(player)) {
            return true;
        }
    }
    return false;
}

void Game::displayWinner() {
    Player& winner = players[(currentPlayerIndex + 1) % 2];
    std::cout << "\n¡" << winner.getName() << " gana!\n";
}

void Game::run() {
    int choice;
    do {
        displayMenu();
        std::cin >> choice;
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Entrada invalida. Intenta de nuevo.\n";
            continue;
        }
        switch (choice) {
            case 1:
                startGame();
                break;
            case 2:
                showRules();
                break;
            case 3:
                std::cout << "Saliendo...\n";
                break;
            default:
                std::cout << "Opcion invalida.\n";
        }
    } while (choice != 3);
}