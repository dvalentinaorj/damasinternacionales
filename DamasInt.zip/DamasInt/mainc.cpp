#include "Game.h"

// Creado por IA
int main() {
    Game game;
    game.run();
    return 0;
}