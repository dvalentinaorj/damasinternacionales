#include "Piece.h"

Piece::Piece(char sym, Player& own) : symbol(sym), owner(&own), isKingFlag(false) {}

char Piece::getSymbol() const {
    return symbol;
}

Player* Piece::getOwner() const {
    return owner;
}

bool Piece::isKing() const {
    return isKingFlag;
}

void Piece::crown() {
    isKingFlag = true;
}