#ifndef PIECE_H
#define PIECE_H

#include "Player.h"

class Piece {
private:
    char symbol;
    Player* owner;
    bool isKingFlag;

public:
    Piece(char sym, Player& own);
    char getSymbol() const;
    Player* getOwner() const;
    bool isKing() const;
    void crown();
};

#endif