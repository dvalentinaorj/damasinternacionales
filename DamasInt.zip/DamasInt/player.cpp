#include "Player.h"

Player::Player(std::string n, char s) : name(n), symbol(s), piecesLeft(20) {}

std::string Player::getName() const {
    return name;
}

char Player::getSymbol() const {
    return symbol;
}

int Player::getPiecesLeft() const {
    return piecesLeft;
}

void Player::removePiece() {
    if (piecesLeft > 0) piecesLeft--;
}