#ifndef PLAYER_H
#define PLAYER_H

#include <string>

class Player {
private:
    std::string name;
    char symbol;
    int piecesLeft;

public:
    Player(std::string n, char s);
    std::string getName() const;
    char getSymbol() const;
    int getPiecesLeft() const;
    void removePiece();
};

#endif