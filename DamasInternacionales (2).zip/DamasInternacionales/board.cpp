#include "colors.h"
#include "Board.h"
#include <iostream>

Board::Board()
{
    grid.resize(SIZE, std::vector<Piece *>(SIZE, nullptr));
}

Board::~Board()
{
    for (auto &row : grid)
    {
        for (auto &piece : row)
        {
            delete piece;
        }
    }
}

void Board::initializeBoard(Player &p1, Player &p2)
{
    for (auto &row : grid)
    {
        for (auto &piece : row)
        {
            delete piece;
            piece = nullptr;
        }
    }

    int piecesPlaced = 0;
    for (int row = 0; row < 4 && piecesPlaced < 20; ++row)
    {
        for (int col = 0; col < SIZE && piecesPlaced < 20; ++col)
        {
            if (isDarkSquare(row, col))
            {
                grid[row][col] = new Piece(p1.getSymbol(), p1);
                piecesPlaced++;
            }
        }
    }

    piecesPlaced = 0;
    for (int row = 6; row < SIZE && piecesPlaced < 20; ++row)
    {
        for (int col = 0; col < SIZE && piecesPlaced < 20; ++col)
        {
            if (isDarkSquare(row, col))
            {
                grid[row][col] = new Piece(p2.getSymbol(), p2);
                piecesPlaced++;
            }
        }
    }
}

void Board::display()
{
    std::cout << "  ";
    for (int col = 0; col < SIZE; ++col)
        std::cout << col << " ";
    std::cout << "\n";

    for (int row = 0; row < SIZE; ++row)
    {
        std::cout << row << " ";
        for (int col = 0; col < SIZE; ++col)
        {
            Piece *piece = grid[row][col];
            if (piece == nullptr)
            {
                std::cout << ". ";
            }
            else
            {
                std::string color = RESET;

                if (piece->getOwner()->getSymbol() == 'X')
                {
                    color = piece->isKing() ? MAGENTA : GREEN; 
                }
                else if (piece->getOwner()->getSymbol() == 'O')
                {
                    color = piece->isKing() ? CYAN : YELLOW;
                }

                std::cout << color << piece->getSymbol() << RESET << " ";
            }
        }
        std::cout << "\n";
    }
}

bool Board::isValidPosition(int row, int col)
{
    return row >= 0 && row < SIZE && col >= 0 && col < SIZE;
}

bool Board::isDarkSquare(int row, int col)
{
    return (row + col) % 2 == 1;
}

bool Board::movePiece(Player &player, int startRow, int startCol, int endRow, int endCol)
{
    if (!isValidPosition(startRow, startCol) || !isValidPosition(endRow, endCol))
        return false;
    if (!grid[startRow][startCol] || grid[startRow][startCol]->getOwner() != &player)
        return false;
    if (grid[endRow][endCol])
        return false;

    Piece *piece = grid[startRow][startCol];
    int dRow = endRow - startRow;
    int dCol = endCol - startCol;


    if (piece->isKing())
    {
        if (abs(dRow) == abs(dCol))
        {
            int stepRow = dRow > 0 ? 1 : -1;
            int stepCol = dCol > 0 ? 1 : -1;
            int r = startRow + stepRow, c = startCol + stepCol;
            bool captured = false;
            while (r != endRow || c != endCol)
            {
                if (grid[r][c])
                {
                    if (captured || grid[r][c]->getOwner() == &player)
                        return false;
                    captured = true;
                    delete grid[r][c];
                    grid[r][c] = nullptr;
                    player.removePiece(); 
                }
                r += stepRow;
                c += stepCol;
            }
            if (captured || abs(dRow) == 1)
            { 
                grid[endRow][endCol] = piece;
                grid[startRow][startCol] = nullptr;
                crownPieceIfNeeded(endRow, endCol);
                return true;
            }
        }
    }
    else
    {
        int direction = (player.getSymbol() == 'X') ? 1 : -1;
        if (dRow == direction && abs(dCol) == 1)
        {
            grid[endRow][endCol] = piece;
            grid[startRow][startCol] = nullptr;
            crownPieceIfNeeded(endRow, endCol);
            return true;
        }
        else if (dRow == 2 * direction && abs(dCol) == 2)
        {
            int midRow = startRow + direction;
            int midCol = startCol + (dCol > 0 ? 1 : -1);
            
            if (!grid[midRow][midCol]) {
                return false;
            }
            if (grid[midRow][midCol]->getOwner() == &player) {
                return false;
            }
            
            if (grid[midRow][midCol] && grid[midRow][midCol]->getOwner() != &player)
            {
                Player *enemy = grid[midRow][midCol]->getOwner();
                delete grid[midRow][midCol];
                grid[midRow][midCol] = nullptr;
                enemy->removePiece();
                grid[endRow][endCol] = piece;
                grid[startRow][startCol] = nullptr;
                crownPieceIfNeeded(endRow, endCol);
                return true;
            }
        }
    }
    return false;
}

void Board::crownPieceIfNeeded(int row, int col)
{
    if (grid[row][col] && !grid[row][col]->isKing())
    {
        if ((grid[row][col]->getOwner()->getSymbol() == 'X' && row == SIZE - 1) ||
            (grid[row][col]->getOwner()->getSymbol() == 'O' && row == 0))
        {
            grid[row][col]->crown();
        }
    }
}

bool Board::hasMandatoryCaptures(Player &player)
{
    for (int row = 0; row < SIZE; ++row)
    {
        for (int col = 0; col < SIZE; ++col)
        {
            if (grid[row][col] && grid[row][col]->getOwner() == &player)
            {
                if (grid[row][col]->isKing())
                {
                    for (int dr = -1; dr <= 1; dr += 2)
                    {
                        for (int dc = -1; dc <= 1; dc += 2)
                        {
                            int r = row + dr, c = col + dc;
                            if (isValidPosition(r, c) && grid[r][c] && grid[r][c]->getOwner() != &player)
                            {
                                int rr = r + dr, cc = c + dc;
                                if (isValidPosition(rr, cc) && !grid[rr][cc])
                                    return true;
                            }
                        }
                    }
                }
                else
                {
                    int direction = (player.getSymbol() == 'X') ? 1 : -1;
                    for (int dc = -1; dc <= 1; dc += 2)
                    {
                        int midRow = row + direction;
                        int midCol = col + dc;
                        int endRow = row + 2 * direction;
                        int endCol = col + 2 * dc;
                        if (isValidPosition(midRow, midCol) && isValidPosition(endRow, endCol) &&
                            grid[midRow][midCol] && grid[midRow][midCol]->getOwner() != &player &&
                            !grid[endRow][endCol])
                        {
                            return true;
                        }
                    }
                }
            }
        }
    }
    return false;
}

bool Board::canCaptureMore(Player &player, int row, int col)
{
    if (!grid[row][col] || grid[row][col]->getOwner() != &player)
        return false;
    Piece *piece = grid[row][col];
    if (piece->isKing())
    {
        for (int dr = -1; dr <= 1; dr += 2)
        {
            for (int dc = -1; dc <= 1; dc += 2)
            {
                int r = row + dr, c = col + dc;
                if (isValidPosition(r, c) && grid[r][c] && grid[r][c]->getOwner() != &player)
                {
                    int rr = r + dr, cc = c + dc;
                    if (isValidPosition(rr, cc) && !grid[rr][cc])
                        return true;
                }
            }
        }
    }
    else
    {
        int direction = (player.getSymbol() == 'X') ? 1 : -1;
        for (int dc = -1; dc <= 1; dc += 2)
        {
            int midRow = row + direction;
            int midCol = col + dc;
            int endRow = row + 2 * direction;
            int endCol = col + 2 * dc;
            if (isValidPosition(midRow, midCol) && isValidPosition(endRow, endCol) &&
                grid[midRow][midCol] && grid[midRow][midCol]->getOwner() != &player &&
                !grid[endRow][endCol])
            {
                return true;
            }
        }
    }
    return false;
}

bool Board::continueCapture(Player &player, int startRow, int startCol, int endRow, int endCol)
{
    if (!isValidPosition(startRow, startCol) || !isValidPosition(endRow, endCol))
        return false;
    if (!grid[startRow][startCol] || grid[startRow][startCol]->getOwner() != &player)
        return false;
    if (grid[endRow][endCol])
        return false;

    Piece *piece = grid[startRow][startCol];
    int dRow = endRow - startRow;
    int dCol = endCol - startCol;

    if (!piece->isKing()) {
        int direction = (player.getSymbol() == 'X') ? 1 : -1;
        
        if (abs(dRow) == 2 && abs(dCol) == 2) {
            int midRow = startRow + direction;
            int midCol = startCol + dCol / 2;
            
            if (isValidPosition(midRow, midCol) && 
                grid[midRow][midCol] && 
                grid[midRow][midCol]->getOwner() != &player) {
                
                Player *enemy = grid[midRow][midCol]->getOwner();
                delete grid[midRow][midCol];
                grid[midRow][midCol] = nullptr;
                enemy->removePiece();

                grid[endRow][endCol] = piece;
                grid[startRow][startCol] = nullptr;
                crownPieceIfNeeded(endRow, endCol);
                return true;
            }
        }
    }

    return false;
}

bool Board::hasValidMoves(Player &player)
{
    for (int row = 0; row < SIZE; ++row)
    {
        for (int col = 0; col < SIZE; ++col)
        {
            if (grid[row][col] && grid[row][col]->getOwner() == &player)
            {
                Piece *piece = grid[row][col];
                if (piece->isKing())
                {
                    for (int dr = -1; dr <= 1; dr += 2)
                    {
                        for (int dc = -1; dc <= 1; dc += 2)
                        {
                            int r = row + dr, c = col + dc;
                            if (isValidPosition(r, c) && !grid[r][c])
                                return true;
                            if (isValidPosition(r, c) && grid[r][c] && grid[r][c]->getOwner() != &player)
                            {
                                int rr = r + dr, cc = c + dc;
                                if (isValidPosition(rr, cc) && !grid[rr][cc])
                                    return true;
                            }
                        }
                    }
                }
                else
                {
                    int direction = (player.getSymbol() == 'X') ? 1 : -1;
                    for (int dc = -1; dc <= 1; dc += 2)
                    {
                        int r = row + direction, c = col + dc;
                        if (isValidPosition(r, c) && !grid[r][c])
                            return true;
                        int midRow = row + direction, midCol = col + dc;
                        int endRow = row + 2 * direction, endCol = col + 2 * dc;
                        if (isValidPosition(midRow, midCol) && isValidPosition(endRow, endCol) &&
                            grid[midRow][midCol] && grid[midRow][midCol]->getOwner() != &player &&
                            !grid[endRow][endCol])
                            return true;
                    }
                }
            }
        }
    }
    return false;
}