#ifndef BOARD_H
#define BOARD_H

#include "Piece.h"
#include "Player.h"
#include <vector>

class Board {
private:
    std::vector<std::vector<Piece*>> grid;
    const int SIZE = 10;

    bool isValidPosition(int row, int col);
    bool isDarkSquare(int row, int col);
    void crownPieceIfNeeded(int row, int col);

public:
    Board();
    ~Board();
    void initializeBoard(Player& p1, Player& p2);
    void display();
    bool movePiece(Player& player, int startRow, int startCol, int endRow, int endCol);
    bool hasMandatoryCaptures(Player& player);
    bool canCaptureMore(Player& player, int row, int col);
    bool continueCapture(Player &player, int startRow, int startCol, int endRow, int endCol);
    bool hasValidMoves(Player& player);
};

#endif