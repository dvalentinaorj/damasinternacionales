#ifndef COLORS_H
#define COLORS_H

#define RESET   "\033[0m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define MAGENTA "\033[35m" 
#define CYAN    "\033[36m" 

#endif