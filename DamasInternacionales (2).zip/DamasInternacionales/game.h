#ifndef GAME_H
#define GAME_H

#include "Board.h"
#include "Player.h"
#include <vector>


class Game {
private:
    Board board;
    std::vector<Player> players;
    int currentPlayerIndex;
    bool gameOver;

    void displayMenu();
    void startGame();
    void showRules();
    void handleTurn();
    bool checkVictory();
    void displayWinner();

public:
    Game();
    void run();
};

#endif